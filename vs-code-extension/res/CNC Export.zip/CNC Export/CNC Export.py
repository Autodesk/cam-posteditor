#Author-Boopathi
#Description-Dumper Export and CNC file export
import adsk.core, adsk.fusion, adsk.cam, traceback,os

# Global list to keep all event handlers in scope.
# This is only needed with Python.
handlers = []

def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui  = app.userInterface

        # Get the CommandDefinitions collection.
        cmdDefs = ui.commandDefinitions
        
        addinDefnition = cmdDefs.addButtonDefinition('ExportPostID','Dumper Output','Create Post dumper output','Resources')  


        clickAddins = ExportPostCommandCreatedHandler()
        addinDefnition.commandCreated.add(clickAddins)
        handlers.append(clickAddins)
        
        # Get the ADD-INS panel in the model workspace. 
        addInsPanel = ui.allToolbarPanels.itemById('CAMActionPanel')

        # Add the button to the bottom of the panel.
        buttonControl = addInsPanel.controls.addCommand(addinDefnition)

        buttonControl.isPromotedByDefault = True
        buttonControl.isPromoted = True
       
        # CNC Export Toolbar codes
        CNCaddInsDef = cmdDefs.addButtonDefinition('ExportCNCID','CNC Output','Create CNC Output for HSM Post Edit Utility for VS code','Resources/cnc')
        
        clickCNCaddIns = ExportCNCCommandCreatedHandler()
        CNCaddInsDef.commandCreated.add(clickCNCaddIns)
        handlers.append(clickCNCaddIns)

        CNCaddInsPanel = ui.allToolbarPanels.itemById('CAMActionPanel')

        CNCbuttonControl = CNCaddInsPanel.controls.addCommand(CNCaddInsDef)
        CNCbuttonControl.isPromotedByDefault = True
        CNCbuttonControl.isPromoted = True

    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))

class ExportPostCommandCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            app = adsk.core.Application.get()
            ui  = app.userInterface
            eventArgs = adsk.core.CommandCreatedEventArgs.cast(args)
            doc = app.activeDocument
            products = doc.products
            product = products.itemByProductType('CAMProductType')
            cam = adsk.cam.CAM.cast(product)

            if cam.setups.count == 0:
                ui.messageBox('There are no CAM operations in the active document.  This script requires the active document to contain at least one CAM operation.',
                            'No CAM Operations Exist',
                            adsk.core.MessageBoxButtonTypes.OKButtonType,
                            adsk.core.MessageBoxIconTypes.CriticalIconType)
                return

            # specify the program name
            programName = doc.name
            outputFolder = cam.temporaryFolder 

            postConfig = os.path.join(cam.genericPostFolder, 'dump.cps') 
        

            # specify the NC file output units
            units = adsk.cam.PostOutputUnitOptions.DocumentUnitsOutput


            count = int(0)
            setupnos = int(cam.setups.count)
            while (count < setupnos):
                active = cam.setups.item(count).isActive
                if active:
                    setup = cam.setups.item(count) 

                    programName = programName+'-'+setup.name
                    # create the postInput object
                    postInput = adsk.cam.PostProcessInput.create(programName, postConfig, outputFolder, units)
                    postInput.isOpenInEditor = True

                    cam.postProcess(setup, postInput)
                    #ui.messageBox('Post processing is complete. The Active Setup results have been written to:\n"' + os.path.join(outputFolder, programName) + '.dmp"') 
                    return
                count = int(count+1)
            
        
        except:
         if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))

class ExportCNCCommandCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            app = adsk.core.Application.get()
            ui  = app.userInterface
            eventArgs = adsk.core.CommandCreatedEventArgs.cast(args)
            doc = app.activeDocument
            products = doc.products
            product = products.itemByProductType('CAMProductType')
            cam = adsk.cam.CAM.cast(product)

            # Get the post file Directory
            dir2 = os.path.dirname(os.path.abspath(__file__))

            if cam.setups.count == 0:
                ui.messageBox('There are no CAM operations in the active document.  This script requires the active document to contain at least one CAM operation.',
                            'No CAM Operations Exist',
                            adsk.core.MessageBoxButtonTypes.OKButtonType,
                            adsk.core.MessageBoxIconTypes.CriticalIconType)
                return
            
            # specify the program name
            programName = doc.name
            outputFolder = cam.temporaryFolder

            postConfig =  os.path.join(dir2 + '\Post\export cnc file to vs code.cps') 
        
            # specify the NC file output units
            units = adsk.cam.PostOutputUnitOptions.DocumentUnitsOutput
            #ui.messageBox('Post processing is complete.')

            count = int(0)
            setupnos = int(cam.setups.count)

            while (count < setupnos):
                active = cam.setups.item(count).isActive
                
                if active:
                    setup = cam.setups.item(count) 

                    programName = programName+'-'+setup.name
                    # create the postInput object
                    postInput = adsk.cam.PostProcessInput.create(programName, postConfig, outputFolder, units)
                    postInput.isOpenInEditor = False

                    cam.postProcess(setup, postInput)
                    ui.messageBox('Post processing is complete.Check in the VS code') 
                    return
                count = int(count+1)
            
        
        except:
         if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))
    
def stop(context):
    try:
        app = adsk.core.Application.get()
        ui  = app.userInterface
        
        # Clean up the UI.
        cmdDef = ui.commandDefinitions.itemById('ExportPostID')
        if cmdDef:
            cmdDef.deleteMe()

        cmdDef1 = ui.commandDefinitions.itemById('ExportCNCID')
        if cmdDef1:
            cmdDef1.deleteMe()
            
        addinsPanel = ui.allToolbarPanels.itemById('CAMActionPanel')
        cntrl = addinsPanel.controls.itemById('ExportPostID')
        if cntrl:
            cntrl.deleteMe()
        cntrl1 = addinsPanel.controls.itemById('ExportCNCID')
        if cntrl1:
            cntrl1.deleteMe()

    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))	